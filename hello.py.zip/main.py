print"Hello World"
print("Hello World");
Print("Hello World")
print("Hel World")
prin(Hello World